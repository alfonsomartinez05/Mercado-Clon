function irAPagina(pagina) {
  window.location.href = pagina;
}

let total = 0;
let contador = 0;

function agregarAlCarrito(precio) {
  total += precio;
  contador++;
  document.getElementById("contador-carrito").innerText = contador;
  document.getElementById("total-compra").innerText = total.toLocaleString();
}

