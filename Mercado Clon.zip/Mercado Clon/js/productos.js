const productos = {
  1: {
    id: 1,
    titulo: "Smartphone Android",
    precio: 2999,
    descripcion: "Pantalla AMOLED, cámara 64MP, batería 5000mAh",
    imagen: "assets/productos/producto1.jpg",
    categoria: "electronica"
  },
  2: {
    id: 2,
    titulo: "Audífonos Bluetooth",
    precio: 199,
    descripcion: "Cancelación de ruido, 20h de batería",
    imagen: "assets/productos/producto2.jpg",
    categoria: "electronica"
  },
  3: {
    id: 3,
    titulo: "Laptop Gamer",
    precio: 5999,
    descripcion: "Intel i7, 16GB RAM, RTX 4060, SSD 1TB",
    imagen: "assets/productos/producto3.jpg",
    categoria: "computadoras"
  },
  4: {
    id: 4,
    titulo: "Tablet 10\"",
    precio: 3999,
    descripcion: "Pantalla IPS, Android 12, 64GB",
    imagen: "assets/productos/producto4.jpg",
    categoria: "electronica"
  },
  5: {
    id: 5,
    titulo: "Smart TV 50\"",
    precio: 8499,
    descripcion: "4K UHD, HDMI, WiFi",
    imagen: "assets/productos/producto5.jpg",
    categoria: "electronica"
  },
  6: {
    id: 6,
    titulo: "Consola de videojuegos",
    precio: 6999,
    descripcion: "500GB, 2 controles, WiFi",
    imagen: "assets/productos/producto6.jpg",
    categoria: "electronica"
  },
  7: {
    id: 7,
    titulo: "Cámara digital",
    precio: 2599,
    descripcion: "20MP, video Full HD, pantalla giratoria",
    imagen: "assets/productos/producto7.jpg",
    categoria: "electronica"
  },
  8: {
    id: 8,
    titulo: "Parlante Bluetooth",
    precio: 649,
    descripcion: "Sonido estéreo, batería 8h",
    imagen: "assets/productos/producto8.jpg",
    categoria: "electronica"
  },
  9: {
    id: 9,
    titulo: "Mini Proyector",
    precio: 1999,
    descripcion: "Compatible HDMI, USB, 1080p",
    imagen: "assets/productos/producto9.jpg",
    categoria: "electronica"
  },
  10: {
    id: 10,
    titulo: "Router WiFi",
    precio: 599,
    descripcion: "Dual Band, cobertura hasta 100m²",
    imagen: "assets/productos/producto10.jpg",
    categoria: "electronica"
  },
  11: {
    id: 11,
    titulo: "Cargador rápido USB-C",
    precio: 299,
    descripcion: "USB-C 65W, compatible con celulares",
    imagen: "assets/productos/producto11.jpg",
    categoria: "accesorios"
  },
  12: {
    id: 12,
    titulo: "Cable HDMI",
    precio: 199,
    descripcion: "1.5 metros, compatible 4K",
    imagen: "assets/productos/producto12.jpg",
    categoria: "accesorios"
  },
  13: {
    id: 13,
    titulo: "Soporte para celular",
    precio: 99,
    descripcion: "Ajustable para escritorio",
    imagen: "assets/productos/producto13.jpg",
    categoria: "accesorios"
  },
  14: {
    id: 14,
    titulo: "Teclado inalámbrico",
    precio: 499,
    descripcion: "Bluetooth, compatible con Android y PC",
    imagen: "assets/productos/producto14.jpg",
    categoria: "accesorios"
  },
  15: {
    id: 15,
    titulo: "Mouse ergonómico",
    precio: 299,
    descripcion: "Sensor óptico, inalámbrico",
    imagen: "assets/productos/producto15.jpg",
    categoria: "accesorios"
  },
  16: {
    id: 16,
    titulo: "Lámpara LED USB",
    precio: 149,
    descripcion: "Flexible, con interruptor táctil",
    imagen: "assets/productos/producto16.jpg",
    categoria: "accesorios"
  },
  17: {
    id: 17,
    titulo: "Memoria USB 64GB",
    precio: 349,
    descripcion: "Alta velocidad 3.0",
    imagen: "assets/productos/producto17.jpg",
    categoria: "accesorios"
  },
  18: {
    id: 18,
    titulo: "Funda universal para tablet",
    precio: 189,
    descripcion: "Para 9-10 pulgadas, cuero sintético",
    imagen: "assets/productos/producto18.jpg",
    categoria: "accesorios"
  },
  19: {
    id: 19,
    titulo: "Audífonos con cable",
    precio: 99,
    descripcion: "Jack 3.5mm, micrófono incorporado",
    imagen: "assets/productos/producto19.jpg",
    categoria: "accesorios"
  },
  20: {
    id: 20,
    titulo: "Almohadilla para mouse",
    precio: 69,
    descripcion: "Base antideslizante",
    imagen: "assets/productos/producto20.jpg",
    categoria: "accesorios"
  },
  21: {
    id: 21,
    titulo: "Portátil Gamer Thunderobot",
    precio: 28345,
    descripcion: "Gaming Zero Ultra intel core 14th i9 14900HX Rtx4060 16'' 2560x1600 240Hz DDR5 32g SSD 1t Win11 Pro Teclado español",
    imagen: "assets/productos/producto21.jpg",
    categoria: "computadoras"
  },
  22: {
    id: 22,
    titulo: "Mini PC",
    precio: 7999,
    descripcion: "Intel N5095, SSD 256GB",
    imagen: "assets/productos/producto22.jpg",
    categoria: "computadoras"
  },
  23: {
    id: 23,
    titulo: "All-in-One 24\"",
    precio: 8999,
    descripcion: "Intel i5, 8GB RAM, pantalla IPS",
    imagen: "assets/productos/producto23.jpg",
    categoria: "computadoras"
  },
  24: {
    id: 24,
    titulo: "Monitor 27\"",
    precio: 3499,
    descripcion: "Full HD, 75Hz, HDMI",
    imagen: "assets/productos/producto24.jpg",
    categoria: "computadoras"
  },
  25: {
    id: 25,
    titulo: "Teclado mecánico RGB",
    precio: 1099,
    descripcion: "Retroiluminado, switches blue",
    imagen: "assets/productos/producto25.jpg",
    categoria: "computadoras"
  },
  26: {
    id: 26,
    titulo: "Mouse gamer 7200 DPI",
    precio: 499,
    descripcion: "Sensor óptico, luces LED",
    imagen: "assets/productos/producto26.jpg",
    categoria: "computadoras"
  },
  27: {
    id: 27,
    titulo: "Impresora WiFi",
    precio: 2999,
    descripcion: "Multifunción, tinta continua",
    imagen: "assets/productos/producto27.jpg",
    categoria: "computadoras"
  },
  28: {
    id: 28,
    titulo: "Bocinas para PC",
    precio: 399,
    descripcion: "2.1 estéreo, entrada jack 3.5mm",
    imagen: "assets/productos/producto28.jpg",
    categoria: "computadoras"
  },
  29: {
    id: 29,
    titulo: "Silla ergonómica",
    precio: 1599,
    descripcion: "Respaldo reclinable, soporte lumbar",
    imagen: "assets/productos/producto29.jpg",
    categoria: "computadoras"
  },
  30: {
    id: 30,
    titulo: "Regulador de voltaje",
    precio: 299,
    descripcion: "6 contactos, protección contra picos",
    imagen: "assets/productos/producto30.jpg",
    categoria: "computadoras"
  },
  31: {
    id: 31,
    titulo: "Celular Xiaomi Poco F7 12gb",
    precio: 299,
    descripcion: "Celular Xiaomi Poco F7 12 GB Ram 512 GB Rom Dual Sim Blanco",
    imagen: "assets/productos/producto31.jpg",
    categoria: "Electrónicos"
  },
  
  32: {
    id: 32,
    titulo: "Smartwatch Reloj Inteligente",
    precio: 8949,
    descripcion: "Smartwatch Reloj Inteligente Llamada Mujer Hombre P28plus",
    imagen: "assets/productos/producto32.jpg",
    categoria: "Electrónicos"
  },
  33: {
    id: 33,
    titulo: "Occiam T17 Audífonos Inalámbricos Bluetooth",
    precio: 362,
    descripcion: "Audífonos Inalámbricos Occiam T9 In Ear 96H Autonomía Bluetooth 5.4 Cancelación de Ruido HI-FI Conexión Rápid Color Negro a Control Táctil IPX5Type-C",
    imagen: "assets/productos/producto33.jpg",
    categoria: "Accesorios"
  },
  34: {
    id: 34,
    titulo: "Antena De Tv Digital Receptor De Señal Doméstica",
    precio: 8949,
    descripcion: "Antena De Tv Digital Receptor De Señal Doméstica 4k Hd 1080p",
    imagen: "assets/productos/producto34.jpg",
    categoria: "Accesorios"
  },
   35: {
    id: 35,
    titulo: "Acer Gadget E10",
    precio: 8644,
    descripcion: "Acer Gadget E10 ETBook Intel Core I5-12450h 16gb 512gb Ssd Win11 Color Gris",
    imagen: "assets/productos/producto35.jpg",
    categoria: "computadoras"
  },
  36: {
    id: 36,
    titulo: "Laptops Gamer Barata 14.1",
    precio: 4640,
    descripcion: "Laptops Gamer Barata 14.1 16gb Ram 1024gb Ssd Plata Hyuafdd",
    imagen: "assets/productos/producto36.jpg",
    categoria: "computadoras"
  }
};
